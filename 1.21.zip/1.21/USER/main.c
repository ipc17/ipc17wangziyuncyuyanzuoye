#include "stm32f4xx.h"
#include "usart.h"
#include "delay.h"
#include "led.h"
#include "sys.h"
#include "tim.h"
#include "OLED.h"
int main(void)
{
	delay_init(168);
	OLED_Init();
	TIM3_Init(15000,8400);
	
extern int  SECOND;
int MINUTE=0;
int HOUR=0;
  while(1)
	{
	OLED_ShowNum(1,1,HOUR,2);
	OLED_ShowString(1, 3, ":");
	OLED_ShowNum(1,5,MINUTE,2);
	OLED_ShowString(1, 7, ":");
	OLED_ShowNum(1,9,SECOND,2);
    if(SECOND>59)
	{
		SECOND=0;
		MINUTE++;
	}
	if(MINUTE>59)
	{
		MINUTE=0;
	    HOUR++;
	}
	if(HOUR>23)
	{
	HOUR=0;
	}	
}

}
